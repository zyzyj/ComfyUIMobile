// 本地服务：提供网页界面 + 登录态管理 + 按链接抓取商品颜色
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startQrLogin, checkLogin, fetchByUrl, logout, hasAuth } from './lib/capture.mjs';

const __dir = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 8787;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
};

function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

async function readJson(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return {}; }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const p = url.pathname;

  try {
    // ---------- API ----------
    if (p === '/api/status') {
      return send(res, 200, { loggedIn: hasAuth() });
    }

    if (p === '/api/login/start' && req.method === 'POST') {
      const qr = await startQrLogin();
      if (!qr) return send(res, 500, { ok: false, error: '二维码获取失败，请稍后重试' });
      return send(res, 200, { ok: true, qr });
    }

    if (p === '/api/login/check' && req.method === 'POST') {
      const r = await checkLogin();
      return send(res, 200, r);
    }

    if (p === '/api/logout' && req.method === 'POST') {
      logout();
      return send(res, 200, { ok: true });
    }

    if (p === '/api/fetch' && req.method === 'POST') {
      const { url: input } = await readJson(req);
      try {
        const info = await fetchByUrl(input);
        return send(res, 200, { ok: true, ...info });
      } catch (e) {
        return send(res, 200, { ok: false, error: e.message });
      }
    }

    // ---------- 静态文件 ----------
    let file = p === '/' ? '/index.html' : p;
    file = path.join(__dir, 'public', path.normalize(file).replace(/^(\.\.[/\\])+/, ''));
    if (!file.startsWith(path.join(__dir, 'public'))) return send(res, 403, { error: 'forbidden' });
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return send(res, 404, { error: 'not found' });
    const ext = path.extname(file).toLowerCase();
    return send(res, 200, fs.readFileSync(file), MIME[ext] || 'application/octet-stream');
  } catch (e) {
    return send(res, 500, { ok: false, error: e.message });
  }
});

server.listen(PORT, () => {
  console.log('');
  console.log('  拼多多规格生成器 已启动');
  console.log('  ──────────────────────────────');
  console.log(`  请在浏览器打开：http://localhost:${PORT}`);
  console.log('');
  console.log('  首次使用请点「扫码登录」，用拼多多 App 扫码。');
  console.log('  登录态会保存在本机，下次无需再扫。');
  console.log('');
  console.log('  按 Ctrl+C 退出。');
});
