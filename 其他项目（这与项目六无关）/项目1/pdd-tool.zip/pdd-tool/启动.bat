@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo   拼多多规格生成器 启动中...
echo   ------------------------------------
if not exist node_modules (
  echo   首次运行，正在安装依赖（需要联网，约 1 分钟）...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo   依赖安装失败。请确认已安装 Node.js 18 及以上版本。
    pause
    exit /b 1
  )
)
echo   依赖就绪，正在启动服务...
echo.
node server.mjs
pause
